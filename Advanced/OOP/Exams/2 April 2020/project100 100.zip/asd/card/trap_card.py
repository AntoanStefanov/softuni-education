from project.card.card import Card


class TrapCard(Card):
    initial_damage = 120
    initial_health = 5

    def __init__(self, name):
        super().__init__(name, self.initial_damage, self.initial_health)
