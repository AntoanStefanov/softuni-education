from project.card.card import Card


class MagicCard(Card):
    initial_damage = 5
    initial_health = 80

    def __init__(self, name):
        super().__init__(name, self.initial_damage, self.initial_health)

