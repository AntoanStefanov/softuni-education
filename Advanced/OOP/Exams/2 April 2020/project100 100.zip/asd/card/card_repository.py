class CardRepository:
    def __init__(self):
        self.count = 0
        self.cards = []

    def add(self, card):
        if card in self.cards:
            raise ValueError(f"Card {card.name} already exists!")
        self.cards.append(card)
        self.count += 1

    def remove(self, card_name: str):
        if card_name == '':
            raise ValueError("Card cannot be an empty string!")
        for card in self.cards:
            if card.name == card_name:
                self.cards.remove(card)
                self.count -= 1

    def find(self, card_name):
        for card in self.cards:
            if card.name == card_name:
                return card
