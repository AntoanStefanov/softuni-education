class PlayerRepository:
    def __init__(self):
        self.count = 0
        self.players = []

    def add(self, player):
        if player in self.players:
            raise ValueError(f"Player {player.username} already exists!")
        self.players.append(player)
        self.count += 1

    def remove(self, player_username: str):
        if player_username == '':
            raise ValueError("Player cannot be an empty string!")
        player = self.find(player_username)
        self.players.remove(player)
        self.count -= 1

    def find(self, player_username: str):
        for player in self.players:
            if player.username == player_username:
                return player
