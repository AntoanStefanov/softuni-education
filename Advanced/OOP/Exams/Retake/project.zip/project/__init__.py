a = ['hui', 'mui']
x = 'a, b, c'
x = x.split(', ')
print(x)
a.extend(x)
print(a)
