from project.software.software import Software


class LightSoftware(Software):
    def __init__(self, name, capacity_consumption, memory_consumption):
        # Tuk ines vmesto 1.50 napisa 1.5 i vmesto 0.50 napisa 0.5
        super().__init__(name, 'Light', int(capacity_consumption * 1.50), int(memory_consumption * 0.50))
