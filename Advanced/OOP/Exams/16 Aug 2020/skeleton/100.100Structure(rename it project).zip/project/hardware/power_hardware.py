from project.hardware.hardware import Hardware


class PowerHardware(Hardware):
    def __init__(self, name: str, capacity: int, memory: int):
        # Ines napisa memoryto int(memory + memory * 0.75)
        super().__init__(name, 'Power', int(capacity*0.25), int(memory*1.75))

