class Hardware:
    def __init__(self, name: str, type: str, capacity: int, memory: int):
        self.name = name
        self.type = type
        self.capacity = capacity
        self.memory = memory
        self.software_components = []

    def install(self, software):
        pass
        # if self.capacity >= software.capacity_consumption and self.memory >= software.memory_consumption:
        #     self.capacity -= software.capacity_consumption
        #     self.memory -= software.memory_consumption
        #     self.software_components.append(software)

    def uninstall(self, software):
        pass
