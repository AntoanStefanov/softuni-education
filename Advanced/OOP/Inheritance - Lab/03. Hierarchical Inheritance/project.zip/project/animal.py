class Animal:

    @staticmethod
    def eat(): return 'eating...'
