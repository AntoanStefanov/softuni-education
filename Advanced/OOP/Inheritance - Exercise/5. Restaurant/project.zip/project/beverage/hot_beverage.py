from .beverage import Beverage

class HotBeverage(Beverage):
    pass
