from .beverage import Beverage

class ColdBeverage(Beverage):
    pass
