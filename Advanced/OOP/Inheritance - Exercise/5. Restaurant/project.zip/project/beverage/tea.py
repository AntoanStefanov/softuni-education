from .hot_beverage import HotBeverage

class Tea(HotBeverage):
    pass
