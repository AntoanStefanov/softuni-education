from .starter import Starter


class Soup(Starter):
    pass