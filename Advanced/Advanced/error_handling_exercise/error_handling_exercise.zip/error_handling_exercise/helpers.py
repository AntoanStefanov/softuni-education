VALID_DOMAINS = ('com', 'bg', 'org', 'net')
