import { newEl, showView } from "./dom.js";
import { showEdit } from "./edit.js";
import { showHome } from "./home.js";

const section = document.getElementById('movie-details');
section.remove();

const loadingEl = newEl('p', {}, 'Loading...');
section.appendChild(loadingEl);

section.querySelector('span').textContent = 'Liked: 0 Dislike';

const buttonsDIV = section.querySelector('.col-md-4.text-center');
buttonsDIV.addEventListener('click', event => {
    event.preventDefault();

    if (event.target.classList.contains('btn-danger')) {
        deleteMovie(section.attributes["film-id"].value)
            .then(() => {
                showHome();
            })
            .catch(error => alert(error.message));

    } else if (event.target.classList.contains('btn-warning')) {
        showEdit(section.attributes["film-id"].value);

    } else if (event.target.classList.contains('btn-primary')) {
        likeMovie(section.attributes["film-id"].value)
            .then(() => {
                getLikes()
                    .then(likes => {
                        let likesMade = 0;
                        const filmId = section.attributes["film-id"].value;
                        const { id: currentUser } = JSON.parse(sessionStorage.getItem('userData'));
                        likes.forEach(({ _ownerId, movieId }) => {
                            if (_ownerId === currentUser && movieId === filmId) {
                                section.querySelector('span').style.display = '';
                                section.querySelector('.btn-primary').style.display = 'none';
                                return;
                            }
                        });
                        likes.forEach(({ movieId }) => {
                            if (movieId === filmId) {
                                likesMade++;
                            }
                        });
                        section.querySelector('span').textContent = 'Liked: ' + likesMade + '/Dislike';
                    })

            })
            .catch(error => alert(error.message));
    } else if (event.target.classList.contains('enrolled-span')) {
        unlike()
            .then(() => {
                section.querySelector('span').style.display = 'none';
                section.querySelector('.btn-primary').style.display = '';
            })
    }
});

export function showDetails(movieId) {
    section.querySelector('div').style.display = 'none';
    loadingEl.style.display = '';

    showView(section);
    getMovie(movieId)
        .then(movie => {
            showCurrentMovie(movie);
            section.querySelector('div').style.display = '';
            loadingEl.style.display = 'none';
        })
        .catch(error => alert(error.message));
}

function showCurrentMovie(movie) {
    section.querySelector('h1').textContent = 'Movie Title: ' + movie.title;
    section.querySelector('img').src = movie.img;
    section.querySelector('p').textContent = movie.description;
    section.setAttribute('film-id', movie._id);
    section.setAttribute('owner-id', movie._ownerId);

    showProperButtons();
}

async function getMovie(movieId) {
    const url = 'http://localhost:3030/data/movies/' + movieId;

    const response = await fetch(url);

    const movie = response.json();

    return movie;

}

function showProperButtons() {
    const buttons = [...section.querySelectorAll('a')];
    const userButtons = buttons.slice(0, 2);
    const likeButton = buttons[2];
    const likesMsg = section.querySelector('span');
    likesMsg.style.display = 'none';
    likeButton.style.display = 'none';

    const userData = JSON.parse(sessionStorage.getItem('userData'));


    if (userData.id === section.attributes["owner-id"].value) {
        userButtons.forEach(btn => btn.style.display = '');
        likeButton.style.display = 'none';
    } else {
        likeButton.style.display = '';
        getLikes()
            .then(likes => {
                let likesMade = 0;
                const filmId = section.attributes["film-id"].value;
                const { id: currentUser } = JSON.parse(sessionStorage.getItem('userData'));
                likes.forEach(({ _ownerId, movieId }) => {
                    if (_ownerId === currentUser && movieId === filmId) {
                        likesMsg.style.display = '';
                        likeButton.style.display = 'none';
                        return;
                    }
                });
                likes.forEach(({ movieId }) => {
                    if (movieId === filmId) {
                        likesMade++;
                    }
                });
                likesMsg.textContent = 'Liked: ' + likesMade + '/Dislike';
            })
        userButtons.forEach(btn => btn.style.display = 'none');
    }
}

async function deleteMovie(id) {
    const url = 'http://localhost:3030/data/movies/' + id;
    const { token } = JSON.parse(sessionStorage.getItem('userData'));

    const options = {
        method: 'DELETE',
        headers: {
            'X-Authorization': `${token}`
        }
    };

    const response = await fetch(url, options);

    if (response.status === 403) {
        sessionStorage.removeItem('userData');
        updateUserNav();
        showLogin();
    }

    if (response.ok !== true) {
        const err = await response.json();
        throw new Error(err.message);
    }
}

async function likeMovie(movieId) {
    const url = 'http://localhost:3030/data/likes';
    const { token } = JSON.parse(sessionStorage.getItem('userData'));

    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': token
        },
        body: JSON.stringify({ movieId })
    };

    const response = await fetch(url, options);

    if (response.status === 403) {
        sessionStorage.removeItem('userData');
        updateUserNav();
        showLogin();
    }

    if (response.ok !== true) {
        const err = await response.json();
        throw new Error(err.message);
    }

    const result = await response.json();

    return result;
}

async function getLikes() {
    const res = await fetch('http://localhost:3030/data/likes');
    const data = await res.json();
    return data;
}

async function unlike() {
    getLikes()
        .then(likes => {
            let likeId;
            const filmId = section.attributes["film-id"].value;
            const { id: currentUser } = JSON.parse(sessionStorage.getItem('userData'));
            likes.forEach(({ _ownerId, movieId, _id }) => {
                if (_ownerId === currentUser && movieId === filmId) {
                    likeId = _id;
                    return;
                }
            })
            deleteLike(likeId);
        })
        .catch(error => alert(error.message));
}

async function deleteLike(id) {
    const url = 'http://localhost:3030/data/likes/' + id;
    const { token } = JSON.parse(sessionStorage.getItem('userData'));

    const options = {
        method: 'DELETE',
        headers: {
            'X-Authorization': `${token}`
        }
    };

    const response = await fetch(url, options);

    if (response.status === 403) {
        sessionStorage.removeItem('userData');
        updateUserNav();
        showLogin();
    }

    if (response.ok !== true) {
        const err = await response.json();
        throw new Error(err.message);
    }
}


