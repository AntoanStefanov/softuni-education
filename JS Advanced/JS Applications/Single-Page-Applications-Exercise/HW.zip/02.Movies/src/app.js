import { updateUserNav } from "./dom.js";
import { showHome } from "./home.js";
import { showLogin } from "./login.js";
import { showRegister } from "./register.js";

const views = {
    "homeLink": showHome,
    "loginLink": showLogin,
    "registerLink": showRegister
};

const nav = document.querySelector('nav');

document.getElementById('logoutBtn').addEventListener('click', onLogout);
nav.addEventListener('click', onNavClick);

function onNavClick(ev) {
    const view = views[ev.target.id];
    if (typeof view === 'function') {
        ev.preventDefault();
        view();
    }
}

updateUserNav();
showHome();

async function onLogout(ev) {
    ev.preventDefault();
    ev.stopImmediatePropagation();

    const { token } = JSON.parse(sessionStorage.getItem('userData'));

    await fetch('http://localhost:3030/users/logout', {
        headers: {
            'X-Authorization': token
        }
    });

    sessionStorage.removeItem('userData');
    updateUserNav();
    showLogin();
}