import { showCreate } from "./create.js";
import { newEl, showView } from "./dom.js";
import { showDetails } from "./details.js";

const section = document.getElementById('home-page');
const cardDeck = document.querySelector(".card-deck.d-flex.justify-content-center");
const addButton = section.querySelector('#createLink');

addButton.addEventListener('click', ev => {
    ev.preventDefault();
    showCreate();
});

cardDeck.addEventListener('click', ev => {
    ev.preventDefault();
    let target = ev.target;

    if (target.tagName === "BUTTON") {
        target = target.parentElement;
    }
    if (target.tagName === "A") {
        const userData = JSON.parse(sessionStorage.getItem('userData'));
        if (userData !== null) {
            const id = target.dataset.id;
            showDetails(id);
        } else {
            alert('Login/Register to see film details!');
        }

    }
});

section.remove();

export function showHome() {
    showView(section);
    cardDeck.replaceChildren(newEl('p', {}, 'Loading...'));

    const userData = JSON.parse(sessionStorage.getItem('userData'));

    if (userData !== null) {
        addButton.style.display = '';
    } else {
        addButton.style.display = 'none';
    }

    getMovies()
        .then(movies => {
            cardDeck.replaceChildren(...movies.map(createMovieCard));
        })
        .catch(error => {
            const message = "Error: " + error.message;
            cardDeck.replaceChildren(newEl('p', {}, message));
        });
}

async function getMovies() {

    const res = await fetch('http://localhost:3030/data/movies');
    const data = await res.json();

    return data;
}

function createMovieCard(movie) {
    const item = newEl('div', { class: "card mb-4" },
        newEl('img', { class: "card-img-top", src: movie.img, alt: "Card image cap", width: "400" }),
        newEl('div', { class: "card-body" }, newEl('h4', { class: "card-title" }, movie.title)),
        newEl('div', { class: "card-footer" }, newEl('a', { href: "#", "data-id": movie._id },
            newEl('button', { type: "button", class: "btn btn-info" }, "Details"))))

    return item;
}