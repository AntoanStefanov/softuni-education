import { showView, updateUserNav } from "./dom.js";
import { showHome } from "./home.js";
import { showLogin } from "./login.js";

const section = document.getElementById('add-movie');
section.remove();

const form = section.querySelector('form');
form.addEventListener('submit', onSubmit);

export function showCreate() {
    showView(section);
}

function onSubmit(ev) {
    ev.preventDefault();
    
    const formData = new FormData(form);

    const title = formData.get('title').trim();
    const description = formData.get('description').trim();
    const imageUrl = formData.get('imageUrl').trim();

    form.reset();

    if (title === '' || description === '' || imageUrl === '') {
        alert('Fill empty input/s');
        return;
    }

    addMovie(title, description, imageUrl)
        .then(() => showHome())
        .catch(err => alert(err.message));
}

async function addMovie(title, description, img) {
    const url = 'http://localhost:3030/data/movies';
    const { token } = JSON.parse(sessionStorage.getItem('userData'));

    const body = {
        title,
        description,
        img
    };

    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': `${token}`
        },
        body: JSON.stringify(body)
    };

    const response = await fetch(url, options);

    if (response.status === 403) {
        sessionStorage.removeItem('userData');
        updateUserNav();
        showLogin();
    }
}

