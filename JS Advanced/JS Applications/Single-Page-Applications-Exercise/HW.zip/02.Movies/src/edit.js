import { showDetails } from "./details.js";
import { showView, updateUserNav } from "./dom.js";
import { showLogin } from "./login.js";

const section = document.getElementById('edit-movie');
section.remove();
const form = section.querySelector('form');
form.addEventListener('submit', onSubmit)

export function showEdit(movieId) {
    section.setAttribute('movie-id', movieId);
    showView(section);
    getMovie(movieId);

}

async function getMovie(movieId) {
    const url = 'http://localhost:3030/data/movies/' + movieId;

    try {
        const response = await fetch(url);
        const movie = await response.json();
        form.querySelector('#title').value = movie.title;
        form.querySelector('textarea[name="description"]').value = movie.description;
        form.querySelector('#imageUrl').value = movie.img;
    } catch (error) {
        alert(error.message);
    }
}

function onSubmit(ev) {
    ev.preventDefault();

    const formData = new FormData(form);

    const title = formData.get('title').trim();
    const description = formData.get('description').trim();
    const img = formData.get('imageUrl').trim();

    form.reset();

    if (title === '' || description === '' || img === '') {
        alert('Fill empty input/s');
        return;
    }

    editMovie(section.attributes["movie-id"].value, title, description, img)
        .then(movieId => {
            showDetails(movieId);
        })
        .catch(error => alert(error.message));
}

async function editMovie(id, title, description, img) {

    const url = 'http://localhost:3030/data/movies/' + id;
    const { token } = JSON.parse(sessionStorage.getItem('userData'));

    const data = {
        title,
        description,
        img
    };

    const options = {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': token
        },
        body: JSON.stringify(data)
    };

    const response = await fetch(url, options);

    if (response.status === 403) {
        sessionStorage.removeItem('userData');
        updateUserNav();
        showLogin();
    }

    if (response.ok !== true) {
        const err = await response.json();
        throw new Error(err.message);
    }

    return id;

}
