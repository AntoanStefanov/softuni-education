import { showView, updateUserNav } from "./dom.js";
import { showHome } from "./home.js";

const section = document.getElementById('form-sign-up');
section.remove();

const form = section.querySelector('form');
form.addEventListener('submit', onRegister);

export function showRegister() {
    showView(section);
}

async function onRegister(ev) {
    ev.preventDefault();
    const formData = new FormData(form);

    const email = formData.get('email').trim();
    const password = formData.get('password').trim();
    const repeatPassword = formData.get('repeatPassword').trim();

    form.reset();

    if (email === '' || password === '' || repeatPassword === '') {
        alert('Fill empty input/s');
        return;
    }

    if (password !== repeatPassword) {
        alert('Passwords don\'t match!');
        return;
    }

    try {
        const res = await fetch('http://localhost:3030/users/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        if (res.ok !== true) {
            const err = await res.json();
            throw new Error(err.message);
        }

        const userData = await res.json();

        sessionStorage.setItem('userData', JSON.stringify({
            email: userData.email,
            id: userData._id,
            token: userData.accessToken
        }));

        updateUserNav();
        showHome();

    } catch (err) {
        alert(err.message);
    }
}