import { deletePieceById, getPieceById } from '../api/data.js';
import { html } from '../lib.js';
import { getUserData } from '../util.js';

const detailsTemplate = (piece, isOwner, onDelete) =>
  html`>
    <section id="game-details">
      <h1>Game Details</h1>
      <div class="info-section">
        <div class="game-header">
          <img class="game-img" src=${piece.imageUrl}/>
          <h1>${piece.title}</h1>
          <span class="levels">MaxLevel: ${piece.maxLevel}</span>
          <p class="type">${piece.category}</p>
        </div>

        <p class="text">${piece.summary}</p>

        <!-- Bonus ( for Guests and Users ) -->
        <div class="details-comments">
          <h2>Comments:</h2>
          <ul> 
            list all comments for current game (If any)
           <li class="comment">
              <p>Content: I rate this one quite highly.</p>
            </li>
            <li class="comment">
              <p>Content: The best game.</p>
            </li>
          </ul> 
          <!-- Display paragraph: If there are no games in the database -->
           <p class="no-comment">No comments.</p>
        </div>

        ${isOwner
          ? html`<div class="buttons">
              <a href="/edit/${piece._id}" class="button">Edit</a>
              <a @click=${onDelete} href="javascript:void(0)" class="button"
                >Delete</a
              >
            </div>`
          : null}
      </div>

      <!-- Bonus -->
      <!-- Add Comment ( Only for logged-in users, which is not creators of the current game ) -->
      <article class="create-comment">
        <label>Add new comment:</label>
        <form class="form">
          <textarea name="comment" placeholder="Comment......"></textarea>
          <input class="btn submit" type="submit" value="Add Comment" />
        </form>
      </article>
    </section> `;

export async function detailsPage(ctx) {
  // console.log(ctx);
  // console.log(ctx.params);
  // id-to otide v params , shtoto v app.js imame :id placeholder
  const piece = await getPieceById(ctx.params.id);

  // check if user is owner and should buttons be displayed
  const userData = getUserData();
  const isOwner = userData && piece._ownerId == userData.id;

  ctx.render(detailsTemplate(piece, isOwner, onDelete));

  async function onDelete() {
    const choice = confirm('Are you sure you want to delete this piece?');
    if (choice) {
      await deletePieceById(ctx.params.id);
      // ako nqma greshka i koda NE spre
      ctx.page.redirect('/');
    }
  }
}
